﻿public class Script {
	public Entity entity;

	public virtual void Setup() { }
	public virtual void Enter() { }
	public virtual void Loop() { }
	public virtual void FixedLoop() { }
	public virtual void Exit() { }
}
